
# Practice Exam
library(tidyverse)
library(extraDistr)
library(BSDA)




